package inicio;

import trabajos.vectoresymatricez.PanelPrincipal;

public class Inicio {
    public static void main(String[] args) {
        new PanelPrincipal().setVisible(true);
        
    }
 
}
