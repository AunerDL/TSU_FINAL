/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.mx.uttt.listas;

public class Lista {

    //Varaibles de instancia
    //Si no pones private automaticamente se vuelve private
    private String nombre;
    private NodoLista PrimerNodo;
    private NodoLista FinalNodo;
    private Integer Contador = 0;

    //Contructores sobrecargados
    //El contructor vacio inicializa variables de instancia
    //Sobrecarga de constructores
    public Lista() {
        //Este this hace referencia a un constructor que reciba un prametro de nombre
        //como la clase de abajo
        this("eduardo");
    }

    public Lista(String nombre) {
        this.nombre = nombre;
        PrimerNodo = null;
        FinalNodo = null;
        System.out.println("Se Creo nodo: " + nombre);
    }

    //Verifica si el nodo esta vacio. Se sabe que esta vacio su primer y ultimo nodo son null
    public boolean estaVacio() {
//        boolean valor=false;
//        if(primerNodo==null){
//            valor=true;
//        }else{
//            valor= false;
//        }
//        return valor;
        return PrimerNodo == null;
        //Ambos metodos funcionan
    }

    //En este momento el this no tiene mucha importancia
    public String getNombre() {
        return this.nombre;
    }

    public NodoLista getPrimerNodo() {
        return PrimerNodo;
    }

    public NodoLista getUltimoNodo() {
        return this.FinalNodo;
    }

    //Desde aqui se empezaron a crear los nodos
    public void insertarFrente(Object elemento) {
        if (estaVacio()) {
            //// Si es la primera vez se inserta en el primer nodo
            //// El siguiente se pone null
            PrimerNodo = new NodoLista(elemento);
            FinalNodo = PrimerNodo;
        } else {
            PrimerNodo = new NodoLista(elemento, PrimerNodo);
        }
        Contador++;
    }

    //Eliminar desde el frente
    public void eliminarFrente() {
        if (Contador == 1) {
            //// Si es la primera vez se inserta en el primer nodo
            //// El siguiente se pone null
            PrimerNodo = null;
            FinalNodo = PrimerNodo;
        } else {
            PrimerNodo = PrimerNodo.getSiguienteNodo();
            Contador--;
        }
    }

    public void insertarFinal(Object elemento) {
        if (estaVacio()) {
            PrimerNodo = new NodoLista(elemento);
            FinalNodo = PrimerNodo;
        } else {
            FinalNodo.setSiguienteNodo(new NodoLista(elemento));
            FinalNodo = FinalNodo.getSiguienteNodo();
            System.out.println("Entro a que ya hay insertara un ultimo" + elemento + "\n");
        }
        Contador++;
    }

    //Eliminar desde el final
    public void eliminarFinal() {
        if (Contador == 1) {
            //// Si es la primera vez se inserta en el primer nodo
            //// El siguiente se pone null
            PrimerNodo = null;
            FinalNodo = PrimerNodo;
        } else {

            NodoLista Auxiliar = PrimerNodo;

            while (Auxiliar.getSiguienteNodo() != FinalNodo) {
                Auxiliar = Auxiliar.getSiguienteNodo();
            }
            FinalNodo = Auxiliar;
            FinalNodo.setSiguienteNodo(null);
            Contador--;
        }
    }

    public void Busqueda(int datoBuscar) {
        String Mensaje = "";
        NodoLista auxiliar = PrimerNodo;
        Integer cantidad = 1;
        while (auxiliar != null) {
            if ((int) auxiliar.getDato() == datoBuscar) {
                Mensaje = Mensaje + " en nodo :" + cantidad + " \n";
            }
            auxiliar = auxiliar.getSiguienteNodo();
            cantidad++;
        }

        if (Mensaje.length() > 0) {
            Mensaje = "El numero a buscar: " + datoBuscar + " se encontro \n" + Mensaje;
            System.out.println(Mensaje);
        } else {
            System.out.println("No se encontro en la busquedan\n");
        }
    }

//    //Imprimir la lista
//    public void imprimir(){
//        if(estaVacio()){
//            System.out.println(this.nombre);
//            return;
//        }
//        System.out.println(this.nombre);
//        NodoLista auxiliar=PrimerNodo;
//        while (auxiliar!=null) {            
//            System.out.print(auxiliar.getDato()+" -> ");
//            auxiliar=auxiliar.getSiguienteNodo();
//        }
//        System.out.println("\n");
//    }
    public String imprimir() {
        String resultado = "";

        if (estaVacio()) {
            resultado = this.nombre + "\n";
            return resultado;
        }

        resultado = this.nombre + "\n";
        NodoLista auxiliar = PrimerNodo;
        while (auxiliar != null) {
            resultado += auxiliar.getDato() + " -> ";
            auxiliar = auxiliar.getSiguienteNodo();
        }
        resultado += "\n";

        return resultado;
    }

    ///// Lo creo al momento de la interfaz
}
