/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.mx.uttt.listas;
/**
 *
 * @author eduar
 */
class NodoLista {
    //Se inician los nodos
    // El object acepta cualquier nodo
    private Object dato;
    //Esto hace a la clase autereferenciada
    private NodoLista siguienteNodo;
    
    //Constructor para crear el primer nodo de la lista
    //El object captura cualquier dato
    public NodoLista(Object dato){
        //Este es el primer nodo
        //Invoca al contructor de dos parametros que es de abajo. Para eso es el this
        this(dato, null);
    }
    //El primer contructor solo se ejecuta cuando se creo el primer nodo
    //Para crear los demas nodos se invoca el contructor de abajo
    public NodoLista(Object dato, NodoLista nodo){
        this.dato=dato;
        this.siguienteNodo=nodo;
    }

    public Object getDato() {
        return dato;
    }

    public void setSiguienteNodo(NodoLista siguienteNodo) {
        this.siguienteNodo = siguienteNodo;
    }
    
    public NodoLista getSiguienteNodo() {
        return siguienteNodo;
    }
    
    
    
}