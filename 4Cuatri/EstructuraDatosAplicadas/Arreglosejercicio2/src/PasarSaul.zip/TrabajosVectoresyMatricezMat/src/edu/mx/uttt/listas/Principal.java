/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.mx.uttt.listas;

/**
 *
 * @author eduar
 */
public class Principal {

    public static void main(String[] args) {

        Lista objLista = new Lista("EduardoZ");
        objLista.insertarFrente(1);
        objLista.insertarFrente(5);
        objLista.insertarFrente(8);
        objLista.insertarFrente(1);
        objLista.insertarFrente(9);
        objLista.insertarFrente(1);
        objLista.imprimir();
        objLista.eliminarFinal();
        objLista.imprimir();
        
        objLista.Busqueda(1);
    }
}
