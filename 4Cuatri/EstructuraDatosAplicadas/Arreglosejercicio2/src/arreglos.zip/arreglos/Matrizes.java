/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arreglos;

/**
 *
 * @author perez
 */
public class Matrizes {
 
    private int matriz[][];
    private int tamFila;
    private int tamColumna;
    
    public Matrizes(int tamFila, int tamColumna){
        
        this.setTamFila(tamFila);
        this.setTamColumna(tamColumna);
        matriz = new int[this.getTamFila()][this.getTamColumna()];
        
    }

    public int[][] getMatriz() {
        return matriz;
    }

    public void setMatriz(int[][] matriz) {
        this.matriz = matriz; //mal implementado
    }

    public int getTamFila() {
        return tamFila;
    }

    public void setTamFila(int tamFila) {
        
        this.tamFila = (tamFila<=0)?2:tamFila;
    }

    public int getTamColumna() {
        return tamColumna;
    }

    public void setTamColumna(int tamColumna) {
        this.tamColumna = (tamColumna<=0)?2:tamFila;
    }
    
    public void imprimir(){
        for (int i = 0; i < 4; i++) {
            
            for (int j = 0; j < 3; j++) {
               this.matriz[i][j] = (int)(Math.random() * 4);
            }
        }
    }
    
}
