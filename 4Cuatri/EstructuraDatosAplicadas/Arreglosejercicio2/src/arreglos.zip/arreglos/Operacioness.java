/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arreglos;

import javax.swing.JOptionPane;

/**
 *
 * @author perez
 */
public class Operacioness {
    private int vector[];
    private int Matriz1[][], Matriz2[][];
    
    
    
    public Operacioness(int tamanio){
        vector = new int[tamanio];
        
    }
    
    public Operacioness(int tamanio2, int tamanio3, int tamanio4, int tamanio5){
        Matriz1 = new int[tamanio2][tamanio3];
        Matriz2 = new int[tamanio4][tamanio5];
    }
    
    public void llenarArreglo(){
        for (int i = 0; i < vector.length; i++) {
            vector[i]=solicitarValor();
        }
    }
    
    private int solicitarValor(){
        String valor="";
        do{
            valor=JOptionPane.showInputDialog("Introduce el valor");
        }while(!validar(valor));
        return Integer.parseInt(valor);
    }
    
    
    
    
//    public void llenarMatriz(){
//        for (int i = 0; i < filas; i++) {
//            for (int j = 0; j < columnas; j++) {
//                System.out.print("Ingrese el valor para la fila " + (i + 1) + ", columna " + (j + 1) + ": ");
//                matriz[i][j] = scanner.nextInt();
//            }
//        }
//    }
    
    private int solicitarValorM(){
        String valor="";
        do{
            valor=JOptionPane.showInputDialog("Introduce el valor");
        }while(!validar(valor));
        return Integer.parseInt(valor);
    }
    
    
    
    
    private boolean validar(String valor)
    {
        try{
            Integer.parseInt(valor);
            return true;
        }catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(null, "Dato no valido");
            return false;
        }
    }
    public String imprimir(){
        int i=0;
        String cadena="";
        do{
            cadena+=("| "+ vector[i] + " ");
            i++;
        }while(i<vector.length);
        return cadena;        
    }
    
    
    public int sumarValores(){
        int suma=0;
        
        for(int i=0; i<this.vector.length; i++){
            suma+=vector[i];
        }
            return suma;
        }
    
    public int sumarValores(int [] vector){
        int suma2=0;
        
        for (int i = 0; i < this.vector.length; i++) {
            suma2= this.vector[0] + vector[0];
        }
        
        return suma2;
    }
    
    
    
    public int NumeroMayor(){
        
        int mayor = vector[0];
        
        for (int i = 0; i < vector.length; i++) {
            if(vector[i]>mayor){
                mayor = vector[i];
            }
        }
        return mayor;
    }
    
    public int sumaPrimos(){
        int contador = 0;
        for (int i = 0; i < vector.length; i++) {
            if(CalcularPrimos(vector[i])){
                contador ++;
            }
            
        }
        return contador;
    }
    
    private boolean CalcularPrimos(int valor){
        int contador=0;
        for(int i = 1; i<=valor; i++){
            if(valor%i == 0){
                contador ++;
            }
        }
        return contador==2;
    }
    
    public int sumarPares(){
        int suma = 0;
        int i = 0;
        do{
            if(vector[i]%2 == 0){
                suma += vector[i];
            }
            i++;
        }while(i<vector.length);
        
        return suma;
    }
    
    
    
    
//    public string sumar(int vector[]){
//
//
//    }
    
    public int gettamanio(){
    return vector.length;
}
    
    public int[] getvector(){
        return this.vector;
    }
    
    

    public void setVector(int[] vector) {

        if(vector.length == this.vector.length){
        for (int i = 0; i < this.vector.length; i++) {
            this.vector[i] = vector[i];
        }
        }
    }

    public int[] getVector() {
        return vector;
    }
    
    
    public int BusquedaSecuencial(int datoB){
        int numB = -1;
        for (int i = 0; i < vector.length; i++) {
            if (vector[i] == datoB) {
                numB = i+1;
                break;
            }
        }
        return numB;
    }
    
    
    public String OrdenamientoBurbuja(boolean tipo){
        
        
        int n = vector.length;
        String v = "";
        
        if(tipo){
            for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                
                if (vector[j] > vector[j + 1]) {
                    int temp = vector[j];
                    vector[j] = vector[j + 1];
                    vector[j + 1] = temp;
                }
            }
        }
            
        }else{
            for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                
                if (vector[j] < vector[j + 1]) {
                    int temp = vector[j];
                    vector[j] = vector[j + 1];
                    vector[j + 1] = temp;
                }
            }
        }
        }
        
        
        for (int i = 0; i < n; i++) {
        v += Integer.toString(vector[i]) + " | ";
        }
        return v;
        
    }
    
//    public String ArregloOrdenado(){
//        
//      
//        String v = "";
//        int n= vector.length;
//        
//        for (int i = 0; i < n; i++) {
//        v += Integer.toString(vector[i]) + " | ";
//        }
//        return v;
//    }
    
//    public int CopiarArreglos(){
//
//        
//    }

    public void copiaArreglo(int [] vector){
        if (vector.length == this.vector.length) {
            for (int i = 0; i <this.vector.length ; i++) {
            this.vector[i] = vector[i];
        }
    }
}
    
    
//    public int SumarMatrizes(){
//        
//    }
    
    
    @Override
    public String toString(){
        return imprimir();
    }
    
}
