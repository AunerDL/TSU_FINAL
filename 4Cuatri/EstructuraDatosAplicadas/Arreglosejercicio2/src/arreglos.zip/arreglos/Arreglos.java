/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arreglos;

/**
 *
 * @author perez
 */
public class Arreglos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         int [] v1;
        v1 = new int[3];

        double v2 [] = new double[3];

        String v3 [] = {"Java", "JavaScript", "C#", "Python"};

        System.out.println(v1[1]);
        System.out.println(v2[0]);
        v2[2] = 10;
        System.out.println(v2[2]);
    }
    
}
