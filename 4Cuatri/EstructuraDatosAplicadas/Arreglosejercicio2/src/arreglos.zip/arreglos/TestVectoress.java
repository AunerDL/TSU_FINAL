/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arreglos;

import javax.swing.JOptionPane;

/**
 *
 * @author perez
 */
public class TestVectoress {
    public static void main(String[] args) {
        int tamanio=Integer.parseInt(JOptionPane.showInputDialog("Introduce el tamaño del arreglo"));
        
        Operacioness op = new Operacioness(0);
        op.imprimir();
        op.llenarArreglo();
        op.imprimir();
    }
}
