/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arreglos;

/**
 *
 * @author perez
 */
public class PrincipalPru {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            
        
//        int x[][]= new int [3][4];
//        
//        System.out.println(x.length);
//        System.out.println("Filas: " + x[0].length + "\nColumnas: " + x[0].length);
        
        
//        Operacioness obj = new Operacioness(3);
//        Operacioness obj2 = new Operacioness(3);
//        
//        obj.llenarArreglo();
//        obj2.llenarArreglo();
//        
//        obj.sumarValores(obj2.getvector());
//
//        System.out.println(obj + "\n" + obj2);
        
    }
    
    public static void imprimir(int[][] m){
        
        //Matrizes Mat = new Matrizes();
        
        
    }
    
}
