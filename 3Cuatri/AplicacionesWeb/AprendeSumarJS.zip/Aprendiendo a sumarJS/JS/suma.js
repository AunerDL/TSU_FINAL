// Define los numeros aleatorios de 9 a 0
function generarNumeros(){
      //alert('Numeros...');
      document.getElementById('txtNumero1').value=Math.floor(Math.random()*10);
      document.getElementById('txtNumero2').value=Math.floor(Math.random()*10);
}

// Definir la función del contador
var time = 10;

function actualizarTiempo(){
      
      document.getElementById('Tiempo').innerHTML = time + " segundos";
      if(time == 0){
            alert('Fin del tiempo\nNumeros actualizados');
            document.getElementById("generarNumeros()");
      }else{            time--;
            setTimeout("actualizarTiempo()",1000);
      }  

}

// Realizacion de suma
function validarSuma(){
      /*dos formas de declarar variables:
      1 var
      2 variable
      3 let(variable, arreglo)*/
      var num1;
      let num2;
      let resuSuma;
      let resuUsuario;

      num1 = parseInt(document.getElementById('txtNumero1').value);
      num2 = parseInt(document.getElementById('txtNumero2').value);

      resuSuma = num1 + num2;
      resuUsuario = document.getElementById('txtResultado').value;
      //document.getElementById("").style.display = "none";
      if(resuSuma==resuUsuario){
            //alert('Resultado Correcto\nel resultado es: ' + resuSuma)
            document.getElementById("txtResultado").style.backgroundColor = 'green';
            document.getElementById('imagen').src='https://static8.depositphotos.com/1170566/960/i/600/depositphotos_9604781-stock-photo-correct-stamp.jpg';
            
      }else{
            //alert('Resultado Incorrecto\nla suma es: ' + resuSuma);
            document.getElementById("txtResultado").style.backgroundColor = 'red';
            document.getElementById('imagen').src='https://st2.depositphotos.com/1031343/6753/v/600/depositphotos_67538691-stock-illustration-incorrect-stamp.jpg';
            
      }
}
