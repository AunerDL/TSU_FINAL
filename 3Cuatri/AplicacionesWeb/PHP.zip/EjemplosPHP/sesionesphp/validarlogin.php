
<?php
include_once 'ConecionBD.php';
$objConecionBD=new ConecionBD("localhost:3306","root","121314","shopprimebd");

//Variables de formulario
$usuarioU=$_REQUEST['txtusuario'];
$passwordU=$_REQUEST['txtpassword'];

if($objConecionBD->getConectionBD()){

    //Mensaje de conexion
    echo ' Conexion Exitosa ';

    //Se realiza procedimiento almacenado
    $instruccionSQL=$objConecionBD->getConn()->prepare("
    call shopprimebd.sp_validarLogin(:usuario,:clave);
    ");
    $instruccionSQL->bindParam(':usuario',$usuarioU);
    $instruccionSQL->bindParam(':clave',$passwordU);

    //Ejecuta instruccion
    $instruccionSQL->execute();

    //Se realiza arreglo
    $datosConsulta=$instruccionSQL->fetchAll();

    $usuario=$datosConsulta[0]['nomUsuario'];
    $emailUsuario=$datosConsulta[0]['emailUsuario'];
    $nomLogin=$datosConsulta[0]['nomLogin'];

    $password=$datosConsulta[0]['claveLogin'];
    $RolUsuario=$datosConsulta[0]['nomRolUsuario'];

    echo ' nombre: '.$usuarioU;
    echo ' clave: '.$passwordU;
    echo ' rol: '.$RolUsuario;

    if (($usuario==$usuarioU || $emailUsuario==$usuarioU || $nomLogin==$usuarioU)
    && $password==$passwordU 
    && $RolUsuario=="administrador") {
        echo 'Usuario y/o contraseña validos';
        session_start();
        $_SESSION['usuariovalido']=$usuario;
        echo '
        <script>
        window.location.href="paginaadministrador copy.php";
        </script>
        ';
    } else if (($usuario==$usuarioU || $emailUsuario==$usuarioU || $nomLogin==$usuarioU)
    && $password==$passwordU 
    && $RolUsuario=="cliente") {
        echo 'Usuario y/o contraseña validos';
        session_start();
        $_SESSION['usuariovalido']=$usuario;
        echo '
        <script>
        window.location.href="paginausuario.php";
        </script>
        ';
    } else {
        echo ' Usuario y/o contraseña no validos';
    }

}else{

    echo ' Fallo la conexion ';

}

/*
$usuarioU="Gabriel";
$passwordU="123";
$RolUsuario="cliente";

$usuarioF=$_GET['txtusuario'];
$passwordF=$_GET['txtpassword'];
*/
?>