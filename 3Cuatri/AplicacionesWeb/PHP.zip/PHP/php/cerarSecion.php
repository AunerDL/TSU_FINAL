<?php
#   EL SESSION ES COMO CUANDO EL USUARIO INICIA SESION ES TODO LO RELACIONA CON INICIAR SESION
#   EL ISSET VALIDA SI LA VARIBALE CONTIENE ALGO
session_start();
if (isset($_SESSION['usuariovalido'])) {
    session_destroy();
    echo '
    <script>
    window.location.href="fromulario.html";
    </script>
    ';
}


?>