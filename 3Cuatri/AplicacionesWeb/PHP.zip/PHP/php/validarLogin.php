<?php
$usuarioU="Gabo";
$passwordU="123";
$RolUsuario="cliente";
$usuarioF=$_GET['txtusuario'];
$passwordF=$_GET['txtpassword'];

if ($usuarioU==$usuarioF && $passwordU==$passwordF && $RolUsuario=="administrador") {
    echo 'Usuario y/o contraseña validos';
    session_start();
    $_SESSION['usuariovalido']=$usuarioU;
    echo '
    <script>
    window.location.href="paginaAdministrador.php";
    </script>
    ';
} else if ($usuarioU==$usuarioF && $passwordU==$passwordF && $RolUsuario=="cliente") {
    echo 'Usuario y/o contraseña validos';
    session_start();
    $_SESSION['usuariovalido']=$usuarioU;
    echo '
    <script>
    window.location.href="paginaUsuario.php";
    </script>
    ';
} else {
    echo 'Usuario y/o contraseña no validos';
}


?>