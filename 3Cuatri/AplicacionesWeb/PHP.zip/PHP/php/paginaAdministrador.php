<?php
session_start();
if (isset($_SESSION['usuariovalido'])) {

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrador</title>
</head>
<body>
    <div>
        <header>
            <h1>
                Pagina Administrador
            </h1>
            <h3>
                Bienvenido
            </h3>
            <h3>
                <?php
                echo $_SESSION['usuariovalido'];
                ?>
                <a href="cerrarSeion.php">Salir</a>
            </h3>
        </header>
        <section>
            <p> 
                Pagina en construccion
            </p>
        </section>
    </div>
</body>
</html>
<?php
}else{
    echo 'Debes iniciar sesion......';
    echo '<a href="fromulario.html">
    Iniciar Sesion
    </a>';
}
?>