select U.nomUsuario, U.emailUsuario, L.claveLogin, RU.nomRolUsuario
from usuario as U join Login as L
on (U.IDUsuario=L.IDUsuario)
join RolUsuario as RU on (l.IDRolUsuario=RU.IDRolUsuario)
where (U.nomUsuario ="gabriel eduardo" or U.emailUsuario="22300138@uttt.edu.mx")
and L.claveLogin="123";
