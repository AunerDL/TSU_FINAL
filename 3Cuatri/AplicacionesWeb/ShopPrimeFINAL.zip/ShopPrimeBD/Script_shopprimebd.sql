CREATE TABLE Usuario (
  `IDUsuario` INT NOT NULL AUTO_INCREMENT,
  `nomUsuario` VARCHAR(45) NULL,
  `apPaternoUsuario` VARCHAR(45) NULL,
  `apMaternoUsuario` VARCHAR(45) NULL,
  `emailUsuario` VARCHAR(45) NULL,
  `telefonoUsuario` VARCHAR(45) NULL,
  `fotoUsuario` BLOB NULL,
  `nombreFotoUsuario` VARCHAR(45) NULL,
  `statusUsuario` TINYINT NULL,
  PRIMARY KEY (`IDUsuario`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ShopPrimeBD`.`RolUsuario`
-- -----------------------------------------------------
CREATE TABLE RolUsuario (
  `IDRolUsuario` INT NOT NULL AUTO_INCREMENT,
  `nomRolUsuario` VARCHAR(45) NULL,
  `descripcionRolUsuario` VARCHAR(200) NULL,
  PRIMARY KEY (`IDRolUsuario`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ShopPrimeBD`.`Login`
-- -----------------------------------------------------
CREATE TABLE Login (
  `IDLogin` INT NOT NULL AUTO_INCREMENT,
  `nomLogin` VARCHAR(45) NULL,
  `claveLogin` VARCHAR(256) NULL,
  `fechaCreacionLogin` DATE NULL,
  `statusLogin` TINYINT NULL,
  `IDUsuario` INT NULL,
  `IDRolUsuario` INT NULL,
  PRIMARY KEY (`IDLogin`),
  INDEX `fk_login_usuario_idx` (`IDUsuario` ASC) VISIBLE,
  INDEX `fk_login_rolUsuario_idx` (`IDRolUsuario` ASC) VISIBLE,
  CONSTRAINT `fk_login_usuario`
    FOREIGN KEY (`IDUsuario`)
    REFERENCES `Usuario` (`IDUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_login_rolUsuario`
    FOREIGN KEY (`IDRolUsuario`)
    REFERENCES `RolUsuario` (`IDRolUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;