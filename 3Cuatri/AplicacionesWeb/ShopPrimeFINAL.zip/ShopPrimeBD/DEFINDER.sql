CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_validarLogin`(
in nomUsuarioU varchar(45),
in claveLoginU varchar(256)
)
BEGIN
select U.nomUsuario, U.emailUsuario, L.claveLogin, RU.nomRolUsuario
from usuario as U join Login as L
on (U.IDUsuario=L.IDUsuario)
join RolUsuario as RU on (l.IDRolUsuario=RU.IDRolUsuario)
where (U.nomUsuario =nomUsuarioU or U.emailUsuario=nomUsuarioU
or L.nomLogin=nomUsuarioU)
and L.claveLogin=claveLoginU;
END