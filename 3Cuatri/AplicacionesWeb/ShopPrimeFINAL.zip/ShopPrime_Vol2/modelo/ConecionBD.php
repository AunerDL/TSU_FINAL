<?php

//funsion llamada isual como el archivo
class ConecionBD{

      //Atributos
      private $nomServidor;
      private $nomUsuarioServer;
      private $claveUsuarioServer;
      private $nomBaseDatos;
      private $conn;

      //Construcctor
      public function __construct($nomServidor, $nomUsuarioServer, $claveUsuarioServer, $nomBaseDatos){

            //Recive datos de entrada
            $this->nomServidor=$nomServidor;
            $this->nomUsuarioServer=$nomUsuarioServer;
            $this->claveUsuarioServer=$claveUsuarioServer;
            $this->nombreBaseDatos=$nomBaseDatos;

      } 

      //Metodos set y get
      /**
       * Get the value of nomServidor
       */
      public function getNomServidor()
      {
            return $this->nomServidor;
      }

      /**
       * Set the value of nomServidor
       */
      public function setNomServidor($nomServidor): self
      {
            $this->nomServidor = $nomServidor;

            return $this;
      }

      /**
       * Get the value of nomUsuarioServer
       */
      public function getNomUsuarioServer()
      {
            return $this->nomUsuarioServer;
      }

      /**
       * Set the value of nomUsuarioServer
       */
      public function setNomUsuarioServer($nomUsuarioServer): self
      {
            $this->nomUsuarioServer = $nomUsuarioServer;

            return $this;
      }

      /**
       * Get the value of claveUsuarioServer
       */
      public function getClaveUsuarioServer()
      {
            return $this->claveUsuarioServer;
      }

      /**
       * Set the value of claveUsuarioServer
       */
      public function setClaveUsuarioServer($claveUsuarioServer): self
      {
            $this->claveUsuarioServer = $claveUsuarioServer;

            return $this;
      }

      /**
       * Get the value of nomBaseDatos
       */
      public function getNomBaseDatos()
      {
            return $this->nomBaseDatos;
      }

      /**
       * Set the value of nomBaseDatos
       */
      public function setNomBaseDatos($nomBaseDatos): self
      {
            $this->nomBaseDatos = $nomBaseDatos;

            return $this;
      }

      /**
       * Get the value of conn
       */
      public function getConn()
      {
            return $this->conn;
      }

      /**
       * Set the value of conn
       */
      public function setConn($conn): self
      {
            $this->conn = $conn;

            return $this;
      }

      //Metodos
      public function getConectionBD(){
            
            try {
                  //code...
                  $this->conn=new PDO("mysql:host=".$this->getNomServidor().";dbname=".$this->getNomBaseDatos(),$this->getNomUsuarioServer(),$this->getClaveUsuarioServer());
                  $this->conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
                  return true;
            } catch (PDOException $e) {
                  //throw $th;
                  echo 'Error de consexion a la base de datos'. $e->getMessage();
            }

            return false;

      }

}

?>