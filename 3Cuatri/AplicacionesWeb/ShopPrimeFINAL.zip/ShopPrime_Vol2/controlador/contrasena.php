<?php
include_once '../modelo/ConecionBD.php';
$objConecionBD=new ConecionBD("localhost:3306","root","121314","shopprimebd");

$correoUsuario=$_REQUEST['txtcorreo'];

if($objConecionBD->getConectionBD()){

    $instrucionSQL=$objConecionBD->getConn()->prepare("call shopprimebd.sp_cambioContrasena(:emailU);");
    $instrucionSQL->bindParam(':emailU',$correoUsuario);

    $instrucionSQL->execute();
    $datosConsulta=$instrucionSQL->fetchAll();
    $email = $datosConsulta[0]['emailUsuario'];

if ($email==$correoUsuario) {
   
    $enviarpassword= $datosConsulta[0]['claveLogin'];
    $paraCorreo=$correoUsuario;
    $titulo="Recupera tu contraseña";
    $mensaje="Tu contraseña es: ".$enviarpassword;
    $tuCorreo="FROM: gabodeadlivef2@gmail.com ";
        
    if (mail($paraCorreo,$titulo,$mensaje,$tuCorreo)) {
        echo "Correo enviado";

    }else {
        echo "Correo No Enviado";
    }
}else{
    echo "Este correo no existe";
}
}else{
    echo 'ERROR No hay sistema';
}

?>