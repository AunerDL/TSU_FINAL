<?php
include_once '../modelo/ConecionBD.php';
$objConecionBD=new ConecionBD("localhost:3306","root","121314","shopprimebd");

//datos de formulario
$nombreUsuario=$_REQUEST['txtUsuario'];
$apPaternoUsuario=$_REQUEST['txtApPaterno'];
$apMaternoUsuario=$_REQUEST['txtApMaterno'];
$emailUsuario=$_REQUEST['txtEmail'];
$telefonoUsuario=$_REQUEST['txtTelefono'];
$fotoUsuario=addslashes(file_get_contents($_FILES['txtFoto']['tmp_name']));
$nombreLogin=$_REQUEST['txtNombreLogin'];
$claveLogin=$_REQUEST['txtPassword'];
$idRolUsuario=$_REQUEST['txtTipoUsuario'];

if($objConecionBD->getConectionBD()){
    
    //Mensaje de conexion
    echo ' Conexion Exitosa ';
    try{
    //Se realiza procedimiento almacenado
    $instruccionSQL=$objConecionBD->getConn()->prepare("
    call shopprimebd.p_crearCuenta(
        :nombreU,
        :apPaternoU,
        :apMaternoU,
        :emailU,
        :telU,
        :fotoU,
        :nombreLoginU,
        :claveLoginU,
        :idRolU);
    ");
    
    $instruccionSQL->bindParam(':nombreU',$nombreUsuario);
    $instruccionSQL->bindParam(':apPaternoU',$apPaternoUsuario);
    $instruccionSQL->bindParam(':apMaternoU',$apMaternoUsuario);
    $instruccionSQL->bindParam(':emailU',$emailUsuario);
    $instruccionSQL->bindParam(':telU',$telefonoUsuario);
    $instruccionSQL->bindParam(':fotoU',$fotoUsuario);
    $instruccionSQL->bindParam(':nombreLoginU',$nombreLogin);
    $instruccionSQL->bindParam(':claveLoginU',$claveLogin);
    $instruccionSQL->bindParam(':idRolU',$idRolUsuario);
       
 
    //Ejecuta instruccion
    $instruccionSQL->execute();
    /*echo '
    <script>
    window.location.href="../vista/paginas/";
    </script>
    ';*/

    //echo 'Se guardo correctamente los datos de la cuenta'
    }catch(PDOException $e){
        echo 'Error de sintaxis de SQL ' .$e->getMessage();
    }
    $objConecionBD->setConn(null);

}else{
    
    echo ' Fallo la conexion ';

}

?>