<?php
session_start();
if (isset($_SESSION['usuariovalido'])) {

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IndexCliente</title>

    <link rel="stylesheet" href="../../../css/estiloIndex.css">
    <link rel="stylesheet" href="../../../CSS/estiloMenu.css">
    <!--<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">-->
    <link rel="stylesheet" href="Vendor/fontawesome-free-6.4.0-web/css/">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../../../Vendor/bootstrap-5.2.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../CSS/estiloCuenta.css">
    <script src="JS/borde.js"></script>
</head>

<body>
    <div id="contenedor">   
        <!--Encabezado-->
        <header class="container-fluid p-0 bg-dark text-white text-center">
            <div class="row">
                <div class="col p-1 bg-dark text-white">
                    <h2 class="tipoFuente">ShoPrime</h2>
                </div>
                <div id="frmbuscar" class="col-7 p-6 bg-dark text-white" onclick="GenerarBorde();">
                    <form action="" class="input-group mb-3 p-2">
                        <div class="dropdown">
                            <button type="button" class="btn btn-success dropdown-toggle bg-danger" data-bs-toggle="dropdown">
                                Categorias
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="../../../paginas/Ropa.html" target="iframeContenedor">Ropa</a>
                                </li>
                                <li><a class="dropdown-item" href="../../../paginas/Electronicos.html"
                                        target="iframeContenedor">Electronicos</a></li>
                                <li><a class="dropdown-item" href="../../../paginas/Cocina.html"
                                        target="iframeContenedor">Alimentos y bebidas</a></li>
                            </ul>
                        </div>
                            <input type="text" class="form-control" name="txtBuscar" id="txtBuscar" placeholder="Buscar ShopPrime">
                            <button class="btn btn-success bg-danger" type="submit" value="Buscar" name="btnBuscar">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                    class="bi bi-search" viewBox="0 0 16 16">
                                    <path
                                        d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                                </svg>
                            </button>
                    </form>
                </div>
                <!--Carrito-->
                <div class="col p-1 bg-dark text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor"
                        class="bi bi-cart" viewBox="0 0 16 16">
                        <path
                            d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
                    </svg>
                </div>
                <!--Cuenta-->
                <!-- Modal -->
                <div class="col p-1 bg-dark text-white">
                    <div>
                        <div>
                            <!--<button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#myModal">
                              Cuenta
                            <button type="button" class="btn btn-dark"  data-bs-toggle="modal" data-bs-target="#myModal">
                                
                            </button>-->
                            <button type="button" class="btn btn-dark" data-bs-toggle="dropdown" data-bs-target="#myModal">
                            <?php
                                echo $_SESSION['usuariovalido'];
                            ?>
                                    <ol class="dropdown-menu">
                                        <li><a class="dropdown-item" href="editarcuenta.php" target="_blank">editar cuenta</a></li>
                                        <li><a class="dropdown-item" href="../../../../controlador/cerrarSesion.php" target="_blank">Salir</a></li>
                                    </ol>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
                                    <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
                <script>
                    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="Cuenta"]'))
                    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
                        return new bootstrap.Popover(popoverTriggerEl)
                    })
                </script>
            </div>
        </header>
        <!--Fin Encabezado-->

        <!--Menu-->
        <nav>
            <ul>
                <li class="active "> <a href="../../../paginas/Inicio.html" target="iframeContenedor">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-house" viewBox="0 0 16 16">
                            <path
                                d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h9a1.5 1.5 0 0 0 1.5-1.5V8.207l.646.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5ZM13 7.207V13.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V7.207l5-5 5 5Z" />
                        </svg>
                    </a></li>
                <li>
                    <div class="offcanvas offcanvas-start bg-black" id="demo">
                        <div class="offcanvas-header">
                            <h1 class="offcanvas-title bg-dark text-white">Inicio</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
                        </div>
                        <div class="offcanvas-body bg-dark text-white">
                            <p>Categorias</p>
                            <p>Ma vendidos</p>
                            <p>Ofertas</p>
                            <button class="btn btn-secondary" type="button">boton</button>
                        </div>
                    </div>

                    <div class="container-fluid mt-2">
                        <button class="btn btn-dark text-danger" type="button" data-bs-toggle="offcanvas" data-bs-target="#demo">
                            INICIO
                        </button>
                    </div>
                </li>
                <li> <a href="../../../paginas/productos.html" target="iframeContenedor">Productos</a></li>
                <li> <a href="https://twitter.com/EpicGamesES">Juegos</a></li>
                <li> <a href="https://www.epicgames.com/site/es-ES/home?sessionInvalidated=true">Mas vendido</a></li>
                <li> <a href="">Tecnologia</a></li>
                <li class="dropdown">
                <li type="button" class="btn btn- dropdodarkwn-toggle text-danger mt-2" data-bs-toggle="dropdown">
                    Promociones
                </li>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#" target="">Cosina</a></li>
                    <li><a class="dropdown-item" href="#">Musica</a></li>
                    <li><a class="dropdown-item" href="#">Autos</a></li>
                    <li><a class="dropdown-item" href="#">Otros</a></li>
                </ul>
                </li>
                <li> <a href="">Servicio al cliente</a></li>
                
                <!--<li type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                        Launch demo modal
                    </li>
                    <ul class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                        <li class="modal-dialog modal-dialog-centered" role="document">
                          <li class="modal-content">
                            <li class="modal-header">
                              <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </li>
                            <div class="modal-body">
                              ...
                            </li>
                            <li class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              <button type="button" class="btn btn-primary">Save changes</button>
                            </li>
                        </li>
                        </li>
                    </ul>-->
                
                <li style="float:right"><a class="active text-white" href="#about">Help</a></li>
            </ul>
        </nav>
        <!--Fin Menu-->

        <!--Contenido-->
        <section>
            <iframe src="../../../paginas/Inicio.html" frameborder="0" name="iframeContenedor" width="100%" height="800px">
            </iframe>

        </section>
        <!--Fin Contenido-->

        <!--PiePagina-->
        <div class="container">
            <footer class="py-3 my-4">
              <ul class="nav justify-content-center border-bottom pb-3 mb-3">
                <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Home</a></li>
                <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Features</a></li>
                <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Pricing</a></li>
                <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">FAQs</a></li>
                <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">About</a></li>
              </ul>
              <p class="text-center text-muted">&copy; 2022 Company, Inc</p>
            </footer>
          </div>
        <!--Fin PiePagina-->
    </div>

</body>

</html>
<?php
}else{
    echo 'Debes iniciar sesion......';
    echo '<a href="../Cuenta.html">
    Iniciar Sesion
    </a>';
}
?>