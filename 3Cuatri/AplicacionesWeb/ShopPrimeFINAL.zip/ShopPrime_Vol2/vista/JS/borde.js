function GenerarBorde(){

      document.getElementById('txtBuscar').style.border = "3px solid red";
  }